class LetterModel {
  int id;
  String alphabet;

  LetterModel({
    required this.id,
    required this.alphabet,
  });
}
