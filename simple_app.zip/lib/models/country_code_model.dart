class CountryCodeModel {
  String name;
  String dialCode;
  String code;

  CountryCodeModel({
    required this.name,
    required this.dialCode,
    required this.code,
  });
}
