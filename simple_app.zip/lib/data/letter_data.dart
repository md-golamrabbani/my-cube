import 'package:travel/models/letter_model.dart';

List letterData = [
  LetterModel(
    id: 1,
    alphabet: "A",
  ),
  LetterModel(
    id: 2,
    alphabet: "B",
  ),
  LetterModel(
    id: 3,
    alphabet: "C",
  ),
  LetterModel(
    id: 4,
    alphabet: "D",
  ),
  LetterModel(
    id: 5,
    alphabet: "E",
  ),
  LetterModel(
    id: 6,
    alphabet: "F",
  ),
  LetterModel(
    id: 7,
    alphabet: "G",
  ),
  LetterModel(
    id: 8,
    alphabet: "H",
  ),
  LetterModel(
    id: 9,
    alphabet: "I",
  ),
  LetterModel(
    id: 10,
    alphabet: "J",
  ),
  LetterModel(
    id: 11,
    alphabet: "K",
  ),
  LetterModel(
    id: 12,
    alphabet: "L",
  ),
  LetterModel(
    id: 13,
    alphabet: "M",
  ),
  LetterModel(
    id: 14,
    alphabet: "N",
  ),
  LetterModel(
    id: 15,
    alphabet: "O",
  ),
  LetterModel(
    id: 16,
    alphabet: "P",
  ),
  LetterModel(
    id: 17,
    alphabet: "Q",
  ),
  LetterModel(
    id: 18,
    alphabet: "R",
  ),
  LetterModel(
    id: 19,
    alphabet: "S",
  ),
  LetterModel(
    id: 20,
    alphabet: "T",
  ),
  LetterModel(
    id: 21,
    alphabet: "U",
  ),
  LetterModel(
    id: 22,
    alphabet: "V",
  ),
  LetterModel(
    id: 23,
    alphabet: "W",
  ),
  LetterModel(
    id: 24,
    alphabet: "Y",
  ),
  LetterModel(
    id: 25,
    alphabet: "Z",
  ),
];
